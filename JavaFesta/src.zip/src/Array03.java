
public class Array03 {

	public static void main(String[] args) {
		int cnt = 0; // ���� �ִ� ���� ����ġ
		int array[][] = new int[5][5];
		int L = 2, H = 2;

		for (int i = 0; i < array.length; i++) {
			if (i < 3) {
				for (int j = L; j <= H; j++) {
					array[i][j] = ++cnt;

				}
				if (L != 0) {
					L--;
					H++;
				}

			} else {
				++L;
				--H;
				for (int j = L; j <= H; j++) {
					array[i][j] = ++cnt;
				}
			}
		}

		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				System.out.print(array[i][j] + "\t");
			}
			System.out.println();
		}

	}

}
