import java.util.Scanner;

public class P22 {

	public static void main(String[] args) {
		
		int incre=0;
		incre+=1;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("n �Է� : ");
		int n = sc.nextInt();
		
		for(int i=0; i<n; i++ ) {
			
			System.out.println();
		}
		

	}

}
