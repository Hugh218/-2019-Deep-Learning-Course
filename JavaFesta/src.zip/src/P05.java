//1,2,4 ���� ��ȯ . 

public class P05 {
	/*
	 * public static int change124(int a) { if(a%3==1) {
	 * 
	 * } return;
	 * 
	 * }
	 */

	public static void main(String[] args) {

		/* System.out.println(change124(10)); */
	}

}
