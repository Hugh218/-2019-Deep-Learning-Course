import java.util.Scanner;

public class P17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[][] arr = new int[n][n];

		int row, col;
		int i = 1;

		for (row = 0; row < n; row++, i++) {
			for (col = 0; col < n; col++) {
				if (col >= 1)
					arr[row][col] = i + (col * 5);
				else if (col == 0)
					arr[row][col] = i;
			}
		}

		for (row = 0; row < n; row++) {
			for (col = 0; col < n; col++)
				System.out.printf("%3d", arr[row][col]);

			System.out.println();
		}

		sc.close();
	}

}
