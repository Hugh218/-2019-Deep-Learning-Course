//�輭�� ã�� 
public class P07 {
	//public static String findkim(String[] a) {
		

	//}
	
	public static void main(String[] args) {
		String[] names = {"Queen","Tod","Kim"};
	//	System.out.println(findkim(names));
		
		
	}

}
