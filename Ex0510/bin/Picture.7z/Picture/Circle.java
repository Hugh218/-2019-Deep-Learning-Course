package Picture;

public class Circle extends Shape {

	public Circle(String color) {
		cl = color;
		sh = "Circle";
		
	}

}
