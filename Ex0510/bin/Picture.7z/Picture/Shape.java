package Picture;

public class Shape {
	String sh;
	String cl;

	public void output() {
		System.out.println(sh + ":" + cl);
	 
	}
}
