package Picture;

public class Tri extends Shape {

	public Tri(String color) {

		cl = color;
		sh = "Tri";

	}

}
