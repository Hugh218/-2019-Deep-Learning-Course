package Picture;

public class Rect extends Shape {
	
	public Rect(String color) {
		cl = color;
		sh = "Rect";
		
	}
}
